export const categories = [
    { id: 1, type: "Music" },
    { id: 2, type: "Movies" },
    { id: 3, type: "Sports" },
    { id: 4, type: "Tech" },
    { id: 5, type: "Fashion" }
];
